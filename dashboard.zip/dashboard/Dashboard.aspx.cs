﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;

namespace PanahaleSweets.Registration
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                Response.Redirect("~/Registration/Login.aspx");
            }
            else
            {

                if (!IsPostBack)
                {
                    // Bind Charts  
                    BindChart();
                    // Bind Bars  
                    //BindBar();
                }
            }
        }

        #region BarGraph Data

        private void BindBar()
        {
            DataTable dsChartData = new DataTable();
            StringBuilder strScript = new StringBuilder();

            try
            {
                dsChartData = GetChartData1();

                strScript.Append(@"<script type='text/javascript'>  
                    google.load('visualization', '1', {packages: ['corechart']}); </script>  
                      
                    <script type='text/javascript'>  
                     
                    function drawChart() {         
                    var data = google.visualization.arrayToDataTable([  
                    ['Total Amount'],");

                foreach (DataRow row in dsChartData.Rows)
                {
                    strScript.Append("[" + row["TotalAmt"] + "],");
                }
                strScript.Remove(strScript.Length - 1, 1);
                strScript.Append("]);");

                strScript.Append(@" var options = {     
                                    title: 'Weekly Sales',            
                                    is3D: true,          
                                    };   ");

                strScript.Append(@"var chart = new google.visualization.ColumnChart(document.getElementById('bar_div'));          
                                chart.draw(data, options);        
                                }    
                            google.setOnLoadCallback(drawChart);  
                            ");
                strScript.Append(" </script>");

                ltScripts.Text = strScript.ToString();
            }
            catch
            {
            }
            finally
            {
                dsChartData.Dispose();
                strScript.Clear();
            }
        }


        private DataTable GetChartData1()
        {
            DataSet dsData = new DataSet();
            try
            {
                SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionStringsPanahale"].ConnectionString);
                SqlDataAdapter sqlCmd = new SqlDataAdapter("select SUM(TotalAmt) from SALE WHERE DATEDIFF(ww, C_CREATE_DATE, GETDATE()) = 0", sqlCon);
                sqlCon.Open();

                sqlCmd.Fill(dsData);

                sqlCon.Close();
            }
            catch
            {
                throw;
            }
            return dsData.Tables[0];
        }

        #endregion



        #region PieChart Data
        private void BindChart()
        {
            DataTable dsChartData = new DataTable();
            StringBuilder strScript = new StringBuilder();

            try
            {
                dsChartData = GetChartData();

                strScript.Append(@"<script type='text/javascript'>  
                    google.load('visualization', '1', {packages: ['corechart']}); </script>  
                      
                    <script type='text/javascript'>  
                     
                    function drawChart() {         
                    var data = google.visualization.arrayToDataTable([  
                    ['Category Name', 'Number of Products'],");

                foreach (DataRow row in dsChartData.Rows)
                {
                    strScript.Append("['" + row["C_NAME"] + "'," + row["ProductName"] + "],");
                }
                strScript.Remove(strScript.Length - 1, 1);
                strScript.Append("]);");

                strScript.Append(@" var options = {     
                                    title: 'Category Wise Products Count',            
                                    is3D: true,          
                                    };   ");

                strScript.Append(@"var chart = new google.visualization.PieChart(document.getElementById('chart_div'));          
                                chart.draw(data, options);        
                                }    
                            google.setOnLoadCallback(drawChart);  
                            ");
                strScript.Append(" </script>");

                ltScripts.Text = strScript.ToString();
            }
            catch
            {
            }
            finally
            {
                dsChartData.Dispose();
                strScript.Clear();
            }
        }

        private DataTable GetChartData()
        {
            DataSet dsData = new DataSet();
            try
            {
                SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionStringsPanahale"].ConnectionString);
                SqlDataAdapter sqlCmd = new SqlDataAdapter("select cat.C_NAME as C_NAME, count(p.ProductName)as ProductName from CATEGORY as cat join PRODUCT as p on cat.CID=p.CID group by C_Name", sqlCon);
                sqlCon.Open();

                sqlCmd.Fill(dsData);

                sqlCon.Close();
            }
            catch
            {
                throw;
            }
            return dsData.Tables[0];
        }

        #endregion


    }
}